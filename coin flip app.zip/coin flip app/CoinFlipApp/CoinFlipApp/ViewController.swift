//
//  ViewController.swift
//  CoinFlipApp
//
//  Created by Ibrahim Usmani on 2/17/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var changingImage: UIImageView!
    
    var imageList = [#imageLiteral(resourceName: "heads"), #imageLiteral(resourceName: "tails")]
    
    @IBAction func Click(_ sender: UIButton) {
        
        
        var randomPosition = Int.random(in: 0...1)
        
        
        changingImage.image = imageList[randomPosition]
    }
    

}

